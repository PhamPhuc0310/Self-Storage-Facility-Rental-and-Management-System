---
name: SafeBox Secure Storage System
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#44474d'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#74777e'
  outline-variant: '#c4c6ce'
  surface-tint: '#4a5f7f'
  primary: '#001229'
  on-primary: '#ffffff'
  primary-container: '#0f2744'
  on-primary-container: '#798fb1'
  inverse-primary: '#b2c8ed'
  secondary: '#0051d5'
  on-secondary: '#ffffff'
  secondary-container: '#316bf3'
  on-secondary-container: '#fefcff'
  tertiary: '#00160c'
  on-tertiary: '#ffffff'
  tertiary-container: '#002d1d'
  on-tertiary-container: '#1fa072'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d4e3ff'
  primary-fixed-dim: '#b2c8ed'
  on-primary-fixed: '#021c39'
  on-primary-fixed-variant: '#324866'
  secondary-fixed: '#dbe1ff'
  secondary-fixed-dim: '#b4c5ff'
  on-secondary-fixed: '#00174b'
  on-secondary-fixed-variant: '#003ea8'
  tertiary-fixed: '#85f8c4'
  tertiary-fixed-dim: '#68dba9'
  on-tertiary-fixed: '#002114'
  on-tertiary-fixed-variant: '#005137'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  display-hero:
    fontFamily: Be Vietnam Pro
    fontSize: 44px
    fontWeight: '700'
    lineHeight: 54px
    letterSpacing: -0.02em
  display-hero-mobile:
    fontFamily: Be Vietnam Pro
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.015em
  headline-lg:
    fontFamily: Be Vietnam Pro
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Be Vietnam Pro
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Be Vietnam Pro
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 30px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Be Vietnam Pro
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
  body-lg:
    fontFamily: Be Vietnam Pro
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  body-md:
    fontFamily: Be Vietnam Pro
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: Be Vietnam Pro
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  label-numeric-price:
    fontFamily: Be Vietnam Pro
    fontSize: 20px
    fontWeight: '700'
    lineHeight: 28px
    letterSpacing: -0.01em
  label-badge:
    fontFamily: Be Vietnam Pro
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-button:
    fontFamily: Be Vietnam Pro
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

The design system establishes a high-trust, institutional, yet accessible aesthetic tailored for the modern self-storage real estate market in Vietnam. It blends the functional clarity of commercial real estate platforms with the high-reliability interface standards of modern enterprise logistics and cloud security management.

### Personality & Demographics
- **Brand Attributes:** High-security, transparent, operational, dependable, and structurally sound.
- **Audience:** Urban dwellers needing residential decluttering or seasonal moves, and business owners/SMEs needing inventory, document, and e-commerce fulfillment hubs across major metropolitan centers in Vietnam (HCMC, Hanoi, Da Nang).
- **Emotional Response:** Reassurance of physical safety (climate control, 24/7 CCTV, smart access locks), pricing clarity (no hidden utility charges), and frictionless spatial estimation (visualizing cubic meters and square meters effortlessly).

### Design Movement & Visual Direction
The system applies **Corporate Modern with Tactile Utilitarian accents**. It uses deep industrial blues alongside crisp slate surfaces, subtle inner-border definitions, structured spatial cards, and clear status indicators that echo commercial architectural signage and logistics management panels.

## Colors

The palette leverages a deep oceanic foundation for security and corporate stability, balanced by high-clarity electric blues for primary actions and spatial statuses.

### Palette Architecture
- **Primary (`#0F2744`):** Industrial Deep Navy used for top navigation, primary headers, facility map markers, active portal sidebars, and critical master actions. Evokes steel lockers, reinforced doors, and architectural permanence.
- **Secondary (`#2563EB`):** Electric Trust Blue dedicated to interactive controls, booking CTAs, active filter chips, step wizards, and highlighted unit dimensions.
- **Tertiary / Availability (`#059669`):** Emerald Green strictly reserved for unit availability statuses ("Còn trống", "Sẵn sàng bàn giao"), confirmed payments, and environmental security indicators (e.g., "Kiểm soát độ ẩm 24/7").
- **Neutral & Canvas:**
  - Background Base: `#F8FAFC` (Slate 50) for effortless eye comfort in dense portal data tables and listing views.
  - Surface Containers: `#FFFFFF` (Pure White) with crisp `#E2E8F0` (Slate 200) structural framing.
  - Text Hierarchy: `#0F172A` (Slate 900) for high-contrast titles and numerical rates, `#334155` (Slate 700) for body descriptions, and `#64748B` (Slate 500) for metadata, footnotes, and unit codes.
- **Feedback & Security Alerts:**
  - Alert / Occupied: `#EF4444` (Unit occupied / payment overdue / fire door open).
  - Attention / Pending: `#F59E0B` (Under cleaning / reservation expiring).

## Typography

The typography leverages **Be Vietnam Pro** across all touchpoints to provide native Vietnamese diacritic rendering with precise kerning, neutral stroke geometry, and high legibility at micro and display scales.

### Hierarchy & Usage Rules
- **Vietnamese Diacritics Care:** Line-height tokens are calibrated with a minimum of `1.4x` to `1.5x` ratio to prevent overlapping tonal marks (dấu mũ, dấu ngã, dấu hỏi) in long addresses and warehouse specifications.
- **Price & Metric Values (`label-numeric-price`):** Standardized formatting using tabular lining figures (`font-variant-numeric: tabular-nums`) to ensure vertical alignment of rental numbers, cubic meters (m³), and square meters (m²) across comparison tables.
- **Status & Facility Tags (`label-badge`):** Set with a medium-to-semibold weight and slight letter-spacing to optimize immediate scanning in facility management listings and unit availability matrices.

## Layout & Spacing

The layout balances dual-mode platforms: a conversion-focused Customer Listing Portal and a dense Facility Manager Portal.

### Grid & Layout Structure
- **Public Portal (Search & Discovery):**
  - Uses an asymmetric 25:75 split layout on desktop screens (`≥ 1024px`). 
  - Sticky Left Sidebar (25% width, max 320px): Granular spatial filters (storage type: Locker, Mini Box, Standard Unit, Big Warehouse, climate-controlled, 24/7 keycard access, ground-floor accessibility).
  - Main Panel (75% width): Responsive unit card grid (2-column on desktop, single-column on mobile).
- **Manager Portal (ERP / Admin Operations):**
  - Uses an enclosed fixed-navigation rail (260px desktop, collapsible to 72px icon rail) coupled with a fluid data workspace utilizing auto-fill grids for KPI stat cards and standard horizontally scrollable tables.
- **Breakpoints:**
  - `Mobile` (< 768px): Single-column stacking, sticky bottom floating action bar for booking triggers, sheet modal filters.
  - `Tablet` (768px - 1023px): 2-column unit cards, collapsible drawer filters.
  - `Desktop` (≥ 1024px): Standard 12-column grid container capped at `1280px` max width for customer views, and full fluid edge-to-edge container (capped at `1600px`) for the manager portal.

## Elevation & Depth

Visual hierarchy uses **tonal layering combined with low-contrast structural outlines and subtle ambient shadows**, avoiding heavy drops in favor of architectural precision.

### Elevation Levels
- **Level 0 (Base Canvas):** Background surfaces (`#F8FAFC`). Flat with no elevation.
- **Level 1 (Cards, Units, Data Tables):** Surface white (`#FFFFFF`) with a 1px border (`#E2E8F0`) and an ambient tinted drop shadow: `0 1px 3px 0 rgba(15, 39, 68, 0.05), 0 1px 2px -1px rgba(15, 39, 68, 0.05)`.
- **Level 2 (Hover States & Active Units):** Elevated interactive state for unit cards and filter drop-downs: `0 8px 20px -4px rgba(15, 39, 68, 0.08), 0 4px 6px -2px rgba(15, 39, 68, 0.04)`.
- **Level 3 (Modals, Overlays & Sticky Bars):** Floating elements (Reservation Drawer, Booking confirmation modal, Floorplan zoom modal): `0 20px 25px -5px rgba(15, 39, 68, 0.12), 0 8px 10px -6px rgba(15, 39, 68, 0.08)`.
- **Level 4 (Toasts & Security Notifications):** Real-time warnings (Overdue lockouts, Sensor warnings): `0 25px 50px -12px rgba(15, 39, 68, 0.25)`.

## Shapes

The design system incorporates geometric stability with softened corners (`Level 2: Rounded`) to project technological modernism while maintaining enterprise credibility.

### Radius Assignments
- **Micro Radius (`0.25rem` / `rounded-sm`):** Data table check boxes, tag icons, scrollbar thumbs.
- **Base Components (`0.5rem` / `rounded-base`):** Form inputs, filter pills, table action dropdowns, buttons, facility amenity badges.
- **Card Containers (`1rem` / `rounded-lg`):** Warehouse listing cards, unit pricing cards, KPI summary cards, filter sidebar panels.
- **Modal Containers (`1.5rem` / `rounded-xl`):** Booking checkout modals, facility layout preview containers, mobile sheet headers.

## Components

### 1. Buttons & CTA Elements
- **Primary Action (Rent / Book Now):** Background `#2563EB`, text `#FFFFFF`, radius `rounded-base`, padding `10px 20px`. Hover: `#1D4ED8`. Focus: 3px outer ring `#93C5FD`.
- **Secondary Action (View Layout / Floor Map):** Background `#FFFFFF`, border `1px solid #CBD5E1`, text `#0F2744`. Hover: `#F1F5F9`.
- **Danger Action (Lock Facility / Cancel Contract):** Background `#FEE2E2`, border `1px solid #FCA5A5`, text `#DC2626`. Hover: `#EF4444`, text `#FFFFFF`.

### 2. Unit Storage Listing Card
- **Structure:** Split container with horizontal photo aspect ratio (16:10) or technical dimension schematic on the left/top, followed by structured details.
- **Content Blocks:**
  - **Header:** Storage Name (e.g., "Kho Tự Quản Size M - 8m³ / 3.5m²") + Status Badge ("Có sẵn").
  - **Dimensions Badge Group:** Monospace/Tabular pills displaying Width × Depth × Height (e.g., "2.0m × 1.75m × 2.3m").
  - **Amenities Mini-Row:** Micro-icons with labels: "Máy lạnh", "CCTV 24/7", "Tầng trệt", "Khoá vân tay".
  - **Pricing Footer:** Price highlighted in `#0F2744` with suffix `/tháng` accompanied by a prominent "Đặt Kho" button.

### 3. Status Badges & Chips
- **Available ("Còn trống"):** Background `#ECFDF5`, text `#047857`, border `1px solid #A7F3D0`.
- **Reserved ("Đã giữ chỗ"):** Background `#FEF3C7`, text `#B45309`, border `1px solid #FDE68A`.
- **Occupied ("Đang thuê"):** Background `#F1F5F9`, text `#475569`, border `1px solid #CBD5E1`.
- **Climate Controlled / Secure:** Deep Navy chip `#0F2744` with white text and a mini padlock/thermometer icon.

### 4. Input Fields & Search Bars
- **Listing Search Bar:** Integrated composite input with Location Dropdown ("Quận 7, TP.HCM"), Spatial Need Selector ("Đồ gia đình 2 phòng"), and Date Picker, unified in a single `rounded-lg` floating container with an electric blue submit trigger.
- **Form Controls:** Text inputs feature an inset border of `#CBD5E1` against `#FFFFFF`, shifting to `#2563EB` with an ambient glow on focus. Helper notes specify volume guidelines (e.g., "Chứa được khoảng 35-40 thùng carton chuẩn").

### 5. Facility Manager Data Tables
- **Table Header:** Background `#F8FAFC`, uppercase `#475569`, tracking `0.05em`, fontSize `12px`.
- **Row Styling:** Hover highlight `#F8FAFC`, bottom border `1px solid #E2E8F0`. Row heights minimum `56px` to easily surface storage unit code, tenant name, contract duration, lock status, and monthly billing amount.

### 6. Booking Modal & Spatial Visualizer
- **Size Visualizer Guide:** Interactive slider displaying realistic scale comparisons (e.g., Mini Locker vs. Motorbike storage vs. 3-room apartment storage).
- **Sticky Summary Step:** Step-based checkout (Chọn gói thuê -> Bảo hiểm tài sản -> Xác thực CCCD / MST -> Đặt cọc & Nhận mã khóa thông minh).